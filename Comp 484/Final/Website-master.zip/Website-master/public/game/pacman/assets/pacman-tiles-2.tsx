<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.5" name="pacman-tiles-2" tilewidth="16" tileheight="16" tilecount="833" columns="49">
 <image source="pacman-tiles-2.png" width="786" height="280"/>
</tileset>
